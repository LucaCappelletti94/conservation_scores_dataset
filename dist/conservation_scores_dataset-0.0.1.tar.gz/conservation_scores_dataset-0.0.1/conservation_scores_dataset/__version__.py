"""Current version of package conservation_scores_dataset."""
__version__ = "0.0.1"